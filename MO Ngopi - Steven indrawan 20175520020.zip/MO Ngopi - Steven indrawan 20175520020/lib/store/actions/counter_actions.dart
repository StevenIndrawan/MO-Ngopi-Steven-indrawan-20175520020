class IncrementCountAction {}

class DecrememtCountAction {}