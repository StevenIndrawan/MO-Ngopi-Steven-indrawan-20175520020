class AddToCart{
  final product;
  AddToCart(this.product);
}

class RemoveFromCart{
  final product;
  RemoveFromCart(this.product);
}

class GetCartProducts{}

class GetInitCartProducts{}