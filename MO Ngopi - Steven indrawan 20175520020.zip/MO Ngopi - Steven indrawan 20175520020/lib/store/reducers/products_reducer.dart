import 'package:online_store/store/actions/products_actions.dart';


List productsReducer( currentProducts, action) {
  if (action is GetProducts) {
    currentProducts =  [
      {
        "id": 1,
        "title": "Americano",
        "description":
            " Americano",
        "price": 10000,
        "quantity": 1,
        "thumbnail": "plate1.png"
      },
      {
        "id": 2,
        "title": "Red Velvet",
        "description": "Red Velvet",
        "price": 15000,
        "quantity": 1,
        "thumbnail": "plate2.png"
      },
      {
        "id": 3,
        "title": "Cafe Latte",
        "description": "Cafe Latte",
        "price": 13000,
        "quantity": 1,
        "thumbnail": "plate3.png"
      }
    ];
    return currentProducts;
  }  else {
    return currentProducts;
  }
}
