import 'dart:async';
import 'package:online_store/utils/cart.dart';
import 'package:rxdart/rxdart.dart';

class ProductsBloc {
  static final List _productsInstance = [
    {
      "id": 1,
      "title": "Americano",
      "description":
          "Espresso yang di campur dengan air panas membuat ini kopi yang sangat disukai di negri Paman Sam.",
      "price": 10000,
      "rate" : 3.5,
      "thumbnail": "plate1.png"
    },
    {
      "id": 2,
      "title": "Cafe Latte",
      "description": "Espresso atau kopi yang dicampur dengan susu dan memiliki lapisan busa yang tipis di bagian atasnya.",
      "price": 13000,
      "rate" : 3.2,
      "thumbnail": "plate2.png"
    },
    {
      "id": 3,
      "title": "Red Velvet Latte",
      "description": "Rasa yang manis yang lembut dilidah bercampur dengan rasa pahitnya kopi.",
      "price": 15000,
      "rate" : 5.0,
      "thumbnail": "plate3.png"
    },
    {
      "id": 4,
      "title": "Green Tea",
      "description": "Susu bercampur rasa yang teh hijau pas untuk anak muda jaman sekarang.",
      "price": 15000,
      "rate" : 5.0,
      "thumbnail": "plate4.png"
    },
    {
      "id": 5,
      "title": "Thai Tea",
      "description": "Minuman khas thailand yang kekinian favorite anak muda.",
      "price": 15000,
      "rate" : 5.0,
      "thumbnail": "plate5.png"
    }
  ];

  final _products = new BehaviorSubject<List>(seedValue: _productsInstance);

  Stream<List> get products => _products.stream;

  ProductsBloc() {
    // _additionController.stream.listen(onAdd);
  }
}
